#include <iostream>
#include <numeric>

int calcularLCMde1a20() {
    int lcm = 1;
    for (int i = 1; i <= 20; i++) {
        lcm = lcm * i / std::gcd(lcm, i);
    }
    return lcm;
}

int main() {
    int lcm_1_a_20 = calcularLCMde1a20();
    std::cout << "El número más pequeño divisible por todos los números de 1 a 20 es: " << lcm_1_a_20 << std::endl;
    return 0;
}
