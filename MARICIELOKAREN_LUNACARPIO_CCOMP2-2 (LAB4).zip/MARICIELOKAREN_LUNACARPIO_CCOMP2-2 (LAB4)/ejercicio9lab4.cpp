#include <iostream>
using namespace std;

int main() {
    int objetivo = 1000;

    for (int a = 1; a < objetivo / 2; a++) {
        for (int b = a + 1; b < objetivo / 2; b++) {
            int c = objetivo - a - b;
            if (a * a + b * b == c * c) {
                int producto_abc = a * b * c;
                cout << "El triplete pitagórico es: a = " << a << ", b = " << b << ", c = " << c << endl;
                cout << "El producto abc es: " << producto_abc << endl;
                return 0;
            }
        }
    }

    cout << "No se encontró ningún triplete pitagórico" << endl;
    return 0;
}
