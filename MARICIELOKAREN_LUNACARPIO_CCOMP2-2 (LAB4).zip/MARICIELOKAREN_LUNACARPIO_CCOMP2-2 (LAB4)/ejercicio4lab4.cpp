#include <iostream>
using namespace std; 

bool Palindromo(int numero) {
    int original = numero;
    int reverso = 0;
    while (numero > 0) {
        reverso = reverso * 10 + numero % 10;
        numero /= 10;
    }
    return original == reverso;
}

int PalindromoMasGrande() {
    int palindromoMasGrande = 0;
    for (int i = 100; i < 1000; i++) {
        for (int j = 100; j < 1000; j++) {
            int producto = i * j;
            if (Palindromo(producto) && producto > palindromoMasGrande) {
                palindromoMasGrande = producto;
            }
        }
    }
    return palindromoMasGrande;
}

int main() {
    int palindromo = PalindromoMasGrande();
    cout << "El palíndromo más grande es: " << palindromo << endl;
    return 0;
}