#include <iostream>
using namespace std;

int main() {
    int lim= 4000000; 
    int num1 = 1;
    int num2 = 2;
    int suma = 0;

    while (num1 <= lim) {
        if (num1 % 2 == 0) {
            suma += num1;
        }

        int siguiente = num1 + num2;
        num1 = num2;
        num2 = siguiente;
    }

    cout << "La suma de los términos pares es: " << suma << endl;

    return 0;
}
