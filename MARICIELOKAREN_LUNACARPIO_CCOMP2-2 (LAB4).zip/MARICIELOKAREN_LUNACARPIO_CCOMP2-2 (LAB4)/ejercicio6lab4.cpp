#include <iostream>
using namespace std; 
int main() {
    int n = 100; 
    long long sumaCuadrados = (n * (n + 1) * (2 * n + 1)) / 6;
    long long cuadrado_Suma = ((n * (n + 1)) / 2) * ((n * (n + 1)) / 2);
    long long diferencia = cuadrado_Suma - sumaCuadrados;

    cout << "La diferencia entre la suma de los cuadrados y el cuadrado de la suma de los primeros " << n << " números naturales es: " << diferencia << endl;

    return 0;
}