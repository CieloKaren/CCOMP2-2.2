#include <iostream>
using namespace std;

long long FactorPrimoGrande(long long num) {
    long long factorPrimoMasGrande = -1;

    while (num % 2 == 0) {
        factorPrimoMasGrande = 2;
        num /= 2;
    }

    for (long long i = 3; i * i <= num; i += 2) {
        while (num % i == 0) {
            factorPrimoMasGrande = i;
            num /= i;
        }
    }

    if (num > 1) {
        factorPrimoMasGrande = num;
    }

    return factorPrimoMasGrande;
}

int main() {
    long long num = 600851475143;
    long long factorPrimo = FactorPrimoGrande(num);

    std::cout << "El factor primo más grande de " << num << " es: " << factorPrimo << endl;

    return 0;
}
