#include <iostream>
using namespace std; 
 
int main(){
    int num;
    int num_max, num_min;
    cout << "Ingrese un número: ";
    cin >> num;

    num_max = num;
    num_min = num; 

    for (int i = 1; i < 5; i++){
        cout << "Ingrese un número: ";
        cin >> num;

        if (num > num_max){
            num_max = num;
        }

        if (num < num_min){
            num_min = num;
        }
    }

    cout << "El número mas grande es: " << num_max << endl;
    cout << "El número mas pequeño es: " << num_min << endl;

    return 0;
}