#include <iostream>
using namespace std;

int main(){
    cout << "*****\n****\n***\n **\n*\n " <<endl; // Imprime una piramide inversa de asteriscos "*", cada linea representa una fila de asteriscos con un número decreciente de tal modo formando la piramide inversa.
    return 0;
}