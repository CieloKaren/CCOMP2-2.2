#include <iostream>
using namespace std;

int main(){
    char caracter;

    cout << "Ingresa un caracter; ";
    cin >> caracter;

    int e = static_cast<int>(caracter);

    cout << "El equivalente de " << caracter << "es: " << e << endl;

    return 0;
}