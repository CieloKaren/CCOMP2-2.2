#include <iostream>

using namespace std;

int main()
{
    int edad;
    double fcm_Tanaka, fcm_Gellish, fcm_Nes;

    cout << "Ingrese su edad: ";
    cin >> edad;

    fcm_Tanaka = 208 - 0.7 * edad;
    fcm_Gellish = 207 - 0.7 * edad;
    fcm_Nes = 211 - 0.64 * edad;

    cout << "Su frecuencia cardiaca segun Tanaka en 2001 es: MHR " << fcm_Tanaka << endl;
    cout << "Su frecuencia cardiaca segun Gellish en 2007 es: MHR " << fcm_Gellish << endl;
    cout << "Su frecuencia cardiaca segun Ness en 2012 es: MHR " << fcm_Nes << endl;
}