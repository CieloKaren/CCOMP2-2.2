#include <iostream>
using namespace std;

int main (){
    double millas_totales;
    double costo_gasolina;
    double millas_galon;
    double tarifa_estacionamiento;
    double peaje;

    cout << "Ingrese las millas totales recorridas por día: ";
    cin >> millas_totales;

    cout << "Ingrese el costo por galón de gasolina: ";
    cin >> costo_gasolina;

    cout << "Ingrese las millas promedio por galón: ";
    cin >> millas_galon;

    cout << "Ingrese las tarifas de estacionamiento por día: ";
    cin >> tarifa_estacionamiento;

    cout << "Ingrese los peajes por día: $";
    cin >> peaje;

    double costo_gasolina_dia = (millas_totales / millas_galon) * costo_gasolina;
    double costo_tdia = costo_gasolina_dia + tarifa_estacionamiento + peaje;

     cout << "El costo diario de conducción al trabajo es de: " << costo_tdia << endl;

    return 0;
}