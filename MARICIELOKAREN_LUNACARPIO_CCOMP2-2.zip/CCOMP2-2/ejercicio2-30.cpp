#include <iostream>
using namespace std;

int main(){

    float peso, alt, bmi;
    cout << "Peso: "; cin >> peso;
    cout << "Altura: "; cin >> alt;
    bmi = peso / (alt * alt);

    if (imc < 18.5) {
        cout << bmi << " - Cuenta con bajo de peso";
    }
    if (imc >= 18.5) {
        cout << bmi << " - Cuenta con peso normal";
    }
    if (imc >= 25) {
        cout << bmi << " - Cuenta con sobrepeso";
    }
    if (imc >= 30) {
        cout << bmi << " - Cuenta con obesidad";
    }
    cout << endl;

}