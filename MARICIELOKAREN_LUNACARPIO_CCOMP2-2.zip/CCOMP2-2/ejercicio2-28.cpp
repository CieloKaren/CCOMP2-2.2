#include <iostream>
using namespace std;

int main(){
    int num;

    cout << "Ingrese un número de 4 cifras: ";
    cin >> num;
    
    if (num >= 1000 && num <= 9999){
        int d = num % 10;
        num /= 10;
        int c = num % 10;
        num /= 10;
        int b = num % 10;
        num /= 10;
        int a = num % 10;

        cout << d << "  " << c << "  " << b << "  " << a << endl; 
    }
    else{
        cout << "El número ingresado no es de 4 cifras" << endl;

    }

    return 0;
}