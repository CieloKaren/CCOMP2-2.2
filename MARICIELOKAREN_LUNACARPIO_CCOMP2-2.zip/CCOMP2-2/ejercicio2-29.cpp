#include <iostream>

using namespace std;

int main()
{
    int i;
    cout << "largo_cubo " << "superficie_cubo " << "volumen_cubo" << endl;
    for (i = 0; i < 5; i++) {
        cout << i << "\t" << "\t" << 6 * i * i << "\t" << "\t" << i * i * i << endl;
    }
        cout<<endl;
}